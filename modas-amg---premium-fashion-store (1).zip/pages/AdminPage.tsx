
import React, { useState } from 'react';
import { Plus, Trash2, Edit, Save, X, Image as ImageIcon, LayoutGrid, Package } from 'lucide-react';
import { Product } from '../types';

interface AdminPageProps {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  categories: { name: string; slug: string }[];
  setCategories: React.Dispatch<React.SetStateAction<{ name: string; slug: string }[]>>;
}

const AdminPage: React.FC<AdminPageProps> = ({ products, setProducts, categories, setCategories }) => {
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [newCatName, setNewCatName] = useState('');
  const [view, setView] = useState<'products' | 'categories'>('products');

  const deleteProduct = (id: string) => {
    if (confirm('¿Eliminar este producto?')) {
      setProducts(prev => prev.filter(p => p.id !== id));
    }
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;

    setProducts(prev => {
      const exists = prev.find(p => p.id === editingProduct.id);
      if (exists) {
        return prev.map(p => p.id === editingProduct.id ? editingProduct : p);
      }
      return [...prev, editingProduct];
    });
    setEditingProduct(null);
  };

  const addCategory = () => {
    if (!newCatName) return;
    const slug = newCatName.toLowerCase().replace(/\s+/g, '-');
    setCategories(prev => [...prev, { name: newCatName, slug }]);
    setNewCatName('');
  };

  const deleteCategory = (slug: string) => {
    if (slug === 'all') return;
    setCategories(prev => prev.filter(c => c.slug !== slug));
  };

  return (
    <div className="container mx-auto px-4 md:px-12 py-12 max-w-6xl">
      <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-6">
        <div>
          <h1 className="text-4xl font-black uppercase italic tracking-tighter">Panel de Gestión - MODAS AMG</h1>
          <p className="text-gray-500">Administra tus productos, categorías y fotos aquí.</p>
        </div>
        <div className="flex bg-gray-100 rounded-full p-1 border">
          <button 
            onClick={() => setView('products')}
            className={`px-6 py-2 rounded-full text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-all ${view === 'products' ? 'bg-white shadow-md' : 'opacity-40'}`}
          >
            <Package size={14}/> Productos
          </button>
          <button 
            onClick={() => setView('categories')}
            className={`px-6 py-2 rounded-full text-xs font-black uppercase tracking-widest flex items-center gap-2 transition-all ${view === 'categories' ? 'bg-white shadow-md' : 'opacity-40'}`}
          >
            <LayoutGrid size={14}/> Categorías
          </button>
        </div>
      </div>

      {view === 'products' ? (
        <div className="space-y-8">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-black uppercase tracking-widest">Catálogo de Productos</h2>
            <button 
              onClick={() => setEditingProduct({
                id: Date.now().toString(),
                name: '',
                price: 0,
                category: 'Sneakers',
                description: '',
                images: [''],
                sizes: [38, 39, 40, 41, 42],
                colors: [],
                isNew: false,
                isOnSale: false
              })}
              className="bg-black text-white px-6 py-3 rounded-full font-black uppercase text-xs tracking-widest flex items-center gap-2"
            >
              <Plus size={16}/> Añadir Producto
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map(p => (
              <div key={p.id} className="bg-white border rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                <div className="aspect-video bg-gray-100 relative">
                  <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover" />
                  <div className="absolute top-2 left-2 flex flex-col gap-1">
                    {p.isNew && (
                      <span className="bg-black text-white px-2 py-0.5 text-[8px] font-black uppercase tracking-widest rounded">NUEVO</span>
                    )}
                    {p.isOnSale && (
                      <span className="bg-red-600 text-white px-2 py-0.5 text-[8px] font-black uppercase tracking-widest rounded">OFERTA</span>
                    )}
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[10px] font-black uppercase text-gray-400 tracking-widest">{p.category}</span>
                    <span className="font-bold text-red-600">${p.price}</span>
                  </div>
                  <h3 className="font-black uppercase text-lg truncate mb-4">{p.name}</h3>
                  <div className="flex gap-2">
                    <button onClick={() => setEditingProduct(p)} className="flex-grow py-3 bg-gray-50 rounded-xl font-bold text-xs uppercase hover:bg-gray-100 flex items-center justify-center gap-2">
                      <Edit size={14}/> Editar
                    </button>
                    <button onClick={() => deleteProduct(p.id)} className="px-4 py-3 bg-red-50 text-red-600 rounded-xl hover:bg-red-100">
                      <Trash2 size={14}/>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="max-w-xl mx-auto space-y-8 animate-fade-in">
          <div className="bg-gray-50 rounded-3xl p-8 border">
            <h3 className="text-xl font-black uppercase italic mb-6">Gestionar Categorías</h3>
            <div className="flex gap-3 mb-8">
              <input 
                type="text" 
                placeholder="Nueva categoría..." 
                className="flex-grow bg-white border rounded-xl px-5 py-4 text-sm font-medium focus:ring-2 focus:ring-black outline-none"
                value={newCatName}
                onChange={e => setNewCatName(e.target.value)}
              />
              <button onClick={addCategory} className="bg-black text-white px-6 rounded-xl font-black uppercase text-xs tracking-widest">Añadir</button>
            </div>
            <div className="space-y-3">
              {categories.map(cat => (
                <div key={cat.slug} className="flex items-center justify-between bg-white p-4 rounded-xl border shadow-sm group">
                  <span className="font-bold uppercase text-sm tracking-widest">{cat.name}</span>
                  {cat.slug !== 'all' && (
                    <button onClick={() => deleteCategory(cat.slug)} className="text-gray-300 hover:text-red-500 transition-colors">
                      <Trash2 size={16}/>
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Product Edit Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-[200] bg-black bg-opacity-70 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-3xl p-8 shadow-2xl animate-fade-in">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-black uppercase italic tracking-tighter">Editar Producto</h2>
              <button onClick={() => setEditingProduct(null)}><X size={24}/></button>
            </div>
            <form onSubmit={handleSaveProduct} className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Nombre del producto</label>
                  <input 
                    type="text" required
                    className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black"
                    value={editingProduct.name}
                    onChange={e => setEditingProduct({...editingProduct, name: e.target.value})}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Precio ($)</label>
                    <input 
                      type="number" step="0.01" required
                      className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black"
                      value={editingProduct.price}
                      onChange={e => setEditingProduct({...editingProduct, price: parseFloat(e.target.value)})}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Categoría</label>
                    <select 
                      className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black appearance-none"
                      value={editingProduct.category}
                      onChange={e => setEditingProduct({...editingProduct, category: e.target.value as any})}
                    >
                      {categories.filter(c => c.slug !== 'all').map(c => (
                        <option key={c.slug} value={c.name}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex gap-6 p-4 bg-gray-50 rounded-2xl">
                   <label className="flex items-center gap-3 cursor-pointer">
                     <input 
                       type="checkbox" 
                       className="w-5 h-5 accent-black rounded"
                       checked={editingProduct.isNew || false}
                       onChange={e => setEditingProduct({...editingProduct, isNew: e.target.checked})}
                     />
                     <span className="text-xs font-black uppercase tracking-widest">Es Nuevo</span>
                   </label>
                   <label className="flex items-center gap-3 cursor-pointer">
                     <input 
                       type="checkbox" 
                       className="w-5 h-5 accent-red-600 rounded"
                       checked={editingProduct.isOnSale || false}
                       onChange={e => setEditingProduct({...editingProduct, isOnSale: e.target.checked})}
                     />
                     <span className="text-xs font-black uppercase tracking-widest text-red-600">En Oferta</span>
                   </label>
                </div>

                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Descripción</label>
                  <textarea 
                    className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black min-h-[120px]"
                    value={editingProduct.description}
                    onChange={e => setEditingProduct({...editingProduct, description: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-6">
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">URLs de Imágenes (Separadas por coma)</label>
                  <textarea 
                    className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black min-h-[100px]"
                    value={editingProduct.images.join(', ')}
                    onChange={e => setEditingProduct({...editingProduct, images: e.target.value.split(',').map(s => s.trim())})}
                  />
                  <div className="mt-4 flex gap-2 overflow-x-auto pb-2">
                    {editingProduct.images.map((img, i) => img && (
                      <img key={i} src={img} className="w-16 h-16 object-cover rounded-lg border" alt=""/>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">Tallas (Separadas por coma)</label>
                  <input 
                    type="text"
                    className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black"
                    value={editingProduct.sizes.join(', ')}
                    onChange={e => setEditingProduct({...editingProduct, sizes: e.target.value.split(',').map(s => parseInt(s.trim()))})}
                  />
                </div>
                <button type="submit" className="w-full bg-black text-white py-5 rounded-2xl font-black uppercase tracking-widest text-sm flex items-center justify-center gap-2 shadow-xl hover:bg-gray-900 transition-all">
                  <Save size={18}/> GUARDAR CAMBIOS
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      <style>{`
        @keyframes fade-in { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade-in { animation: fade-in 0.4s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default AdminPage;
