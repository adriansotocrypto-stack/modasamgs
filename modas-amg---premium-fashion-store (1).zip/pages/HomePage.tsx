
import React, { useMemo } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { Star, ArrowRight, Zap, TrendingUp } from 'lucide-react';
import { Product } from '../types';

interface HomePageProps {
  products: Product[];
  categories: { name: string; slug: string }[];
  addToCart: (product: Product, size: number) => void;
}

const HomePage: React.FC<HomePageProps> = ({ products, categories, addToCart }) => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const selectedCategory = queryParams.get('category') || 'all';

  const filteredProducts = useMemo(() => {
    if (selectedCategory === 'all') return products;
    return products.filter(p => p.category === selectedCategory);
  }, [products, selectedCategory]);

  const activeCategoryName = useMemo(() => {
    const found = categories.find(c => c.slug === selectedCategory);
    return found ? found.name : 'Productos';
  }, [categories, selectedCategory]);

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[60vh] md:h-[80vh] bg-gray-100 overflow-hidden flex items-center">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&q=80&w=2000" 
            className="w-full h-full object-cover brightness-75"
            alt="Hero Banner"
          />
        </div>
        <div className="container mx-auto px-4 md:px-12 relative z-10">
          <div className="max-w-2xl text-white">
            <span className="inline-block bg-red-600 px-3 py-1 text-xs font-black uppercase tracking-widest rounded mb-6">
              NUEVA COLECCIÓN 2024
            </span>
            <h1 className="text-5xl md:text-8xl font-black uppercase tracking-tighter leading-none mb-6 italic">
              VISTE EL FUTURO, <br />VIVE MODAS AMG
            </h1>
            <p className="text-lg md:text-xl font-medium opacity-90 mb-10 max-w-lg leading-snug">
              Exclusividad y elegancia en cada detalle. Redescubre tu estilo con nosotros.
            </p>
            <div className="flex gap-4">
              <button onClick={() => document.getElementById('catalog')?.scrollIntoView({behavior:'smooth'})} className="bg-white text-black px-10 py-5 rounded-full font-black uppercase text-sm tracking-wider hover:bg-gray-100 transition-all flex items-center gap-2">
                VER CATÁLOGO <ArrowRight size={18} />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Badges */}
      <div className="bg-black py-4 overflow-hidden border-y border-gray-800">
        <div className="flex gap-12 animate-marquee whitespace-nowrap">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="flex items-center gap-4 text-white font-black uppercase italic tracking-tighter text-lg opacity-60">
              <span>ENVÍO GRATIS</span> <Zap size={20} className="text-red-500 fill-red-500" />
              <span>PAGO SEGURO</span> <Zap size={20} className="text-red-500 fill-red-500" />
              <span>CALIDAD MODAS AMG</span> <Zap size={20} className="text-red-500 fill-red-500" />
            </div>
          ))}
        </div>
      </div>

      {/* Products Grid */}
      <section id="catalog" className="container mx-auto px-4 md:px-12 py-20">
        <div className="flex flex-col md:flex-row items-end justify-between mb-12 gap-6">
          <div className="max-w-xl">
            <h2 className="text-4xl md:text-6xl font-black uppercase tracking-tighter italic mb-4">
              {selectedCategory === 'all' ? 'DESTACADOS' : activeCategoryName}
            </h2>
            <div className="h-2 w-24 bg-red-600"></div>
          </div>
          
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide w-full md:w-auto">
            {categories.map(cat => (
              <Link
                key={cat.slug}
                to={`/?category=${cat.slug}`}
                className={`px-6 py-2 rounded-full text-xs font-black uppercase tracking-widest transition-all whitespace-nowrap border-2 ${
                  selectedCategory === cat.slug 
                    ? 'bg-black text-white border-black shadow-lg scale-105' 
                    : 'bg-white text-black border-gray-100 hover:border-black'
                }`}
              >
                {cat.name}
              </Link>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-8 gap-y-12">
          {filteredProducts.map(product => (
            <div key={product.id} className="group cursor-pointer">
              <Link to={`/product/${product.id}`} className="block">
                <div className="relative aspect-[4/5] bg-gray-50 rounded-2xl overflow-hidden mb-5">
                  <img 
                    src={product.images[0]} 
                    alt={product.name} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out" 
                  />
                  <div className="absolute top-4 left-4 flex flex-col gap-2">
                    {product.isNew && (
                      <span className="bg-black text-white px-3 py-1 text-[10px] font-black uppercase tracking-widest rounded shadow-lg w-fit">
                        NUEVO
                      </span>
                    )}
                    {product.isOnSale && (
                      <span className="bg-red-600 text-white px-3 py-1 text-[10px] font-black uppercase tracking-widest rounded shadow-lg w-fit">
                        OFERTA
                      </span>
                    )}
                  </div>
                  <div className="absolute bottom-4 left-4 right-4 translate-y-12 group-hover:translate-y-0 transition-transform duration-300">
                    <button className="w-full bg-white text-black py-3 rounded-xl font-bold uppercase text-xs shadow-xl flex items-center justify-center gap-2">
                      VISTA RÁPIDA
                    </button>
                  </div>
                </div>
                
                <div className="space-y-1">
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{product.category}</span>
                  <div className="flex justify-between items-start">
                    <h3 className="text-lg font-black uppercase tracking-tighter leading-tight">{product.name}</h3>
                    <span className="text-lg font-bold text-red-600">${product.price.toFixed(2)}</span>
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </section>

      <style>{`
        @keyframes marquee { 0% { transform: translateX(0); } 100% { transform: translateX(-50%); } }
        .animate-marquee { animation: marquee 30s linear infinite; }
      `}</style>
    </div>
  );
};

export default HomePage;
