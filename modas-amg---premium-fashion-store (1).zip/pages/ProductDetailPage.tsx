
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, ShieldCheck, Truck, RefreshCw, ShoppingBag, ArrowLeft, Plus, Minus, Heart } from 'lucide-react';
import { Product } from '../types';

interface ProductDetailPageProps {
  products: Product[];
  addToCart: (product: Product, size: number) => void;
}

const ProductDetailPage: React.FC<ProductDetailPageProps> = ({ products, addToCart }) => {
  const { id } = useParams();
  const [product, setProduct] = useState<Product | null>(null);
  const [selectedSize, setSelectedSize] = useState<number | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    const found = products.find(p => p.id === id);
    if (found) {
      setProduct(found);
    }
  }, [id, products]);

  if (!product) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Producto no encontrado</h2>
          <Link to="/" className="text-red-600 underline">Volver a la tienda</Link>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    if (selectedSize) {
      for (let i = 0; i < quantity; i++) {
        addToCart(product, selectedSize);
      }
    } else {
      alert("Por favor, selecciona una talla");
    }
  };

  return (
    <div className="container mx-auto px-4 md:px-12 py-12">
      <Link to="/" className="inline-flex items-center gap-2 text-sm font-bold uppercase tracking-widest mb-10 text-gray-400 hover:text-black transition-colors">
        <ArrowLeft size={16} /> VOLVER A LA TIENDA
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 xl:gap-20">
        <div className="lg:col-span-7 flex flex-col md:flex-row gap-6">
          <div className="flex md:flex-col gap-4 order-2 md:order-1">
            {product.images.map((img, idx) => (
              <button 
                key={idx}
                onClick={() => setActiveImage(idx)}
                className={`w-20 h-20 rounded-xl overflow-hidden border-2 transition-all ${activeImage === idx ? 'border-black' : 'border-transparent opacity-60'}`}
              >
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
          <div className="flex-grow aspect-[4/5] bg-gray-50 rounded-3xl overflow-hidden order-1 md:order-2">
            <img 
              src={product.images[activeImage]} 
              alt={product.name} 
              className="w-full h-full object-cover" 
            />
          </div>
        </div>

        <div className="lg:col-span-5 space-y-10">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-black text-red-600 uppercase tracking-[0.2em]">{product.category}</span>
              <div className="flex items-center gap-1 text-yellow-500">
                <Star size={16} fill="currentColor" />
                <span className="text-sm font-bold text-black ml-1">4.9</span>
              </div>
            </div>
            <h1 className="text-4xl md:text-6xl font-black uppercase tracking-tighter italic mb-4 leading-none">
              {product.name}
            </h1>
            <p className="text-3xl font-black text-black">${product.price.toFixed(2)}</p>
          </div>

          <p className="text-gray-500 text-lg leading-relaxed">{product.description}</p>

          <div className="space-y-6">
            <h3 className="font-black uppercase tracking-widest text-sm">SELECCIONA TU TALLA</h3>
            <div className="grid grid-cols-4 md:grid-cols-5 gap-3">
              {product.sizes.map(size => (
                <button
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`py-4 rounded-xl text-sm font-bold border-2 transition-all ${
                    selectedSize === size ? 'bg-black text-white border-black shadow-xl' : 'bg-white text-black border-gray-100 hover:border-black'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-4">
            <div className="flex items-center bg-gray-100 rounded-2xl p-2 h-[72px]">
              <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="p-4 hover:bg-white rounded-xl transition-colors">
                <Minus size={20} />
              </button>
              <span className="w-12 text-center font-black text-xl">{quantity}</span>
              <button onClick={() => setQuantity(q => q + 1)} className="p-4 hover:bg-white rounded-xl transition-colors">
                <Plus size={20} />
              </button>
            </div>
            <button onClick={handleAddToCart} className="flex-grow bg-black text-white rounded-2xl font-black uppercase tracking-widest text-sm flex items-center justify-center gap-3 hover:bg-gray-900 shadow-xl transition-all">
              <ShoppingBag size={20} /> AÑADIR
            </button>
          </div>

          <div className="grid grid-cols-3 gap-6 pt-10 border-t border-gray-100 opacity-60">
            <div className="text-center"><Truck size={20} className="mx-auto mb-1"/><p className="text-[8px] font-black uppercase">Envío AMG</p></div>
            <div className="text-center"><ShieldCheck size={20} className="mx-auto mb-1"/><p className="text-[8px] font-black uppercase">Garantía</p></div>
            <div className="text-center"><RefreshCw size={20} className="mx-auto mb-1"/><p className="text-[8px] font-black uppercase">Cambios</p></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;
