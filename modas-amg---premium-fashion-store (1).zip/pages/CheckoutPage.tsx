
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CreditCard, Truck, ArrowLeft, CheckCircle, ShieldCheck, Lock } from 'lucide-react';
import { CartItem } from '../types';

interface CheckoutPageProps {
  cart: CartItem[];
  total: number;
  clearCart: () => void;
}

const CheckoutPage: React.FC<CheckoutPageProps> = ({ cart, total, clearCart }) => {
  const navigate = useNavigate();
  const [step, setStep] = useState<'info' | 'payment' | 'success'>('info');
  
  // Simulated form states
  const [formData, setFormData] = useState({
    email: '',
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    zip: '',
    cardNumber: '',
    expiry: '',
    cvv: '',
    nameOnCard: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const nextStep = () => {
    if (step === 'info') setStep('payment');
    else if (step === 'payment') {
      // Simulate API call
      setTimeout(() => {
        setStep('success');
        clearCart();
      }, 1500);
    }
  };

  if (cart.length === 0 && step !== 'success') {
    return (
      <div className="h-[70vh] flex flex-col items-center justify-center text-center p-6">
        <h2 className="text-2xl font-black uppercase mb-4 tracking-tighter italic">CARRITO VACÍO</h2>
        <p className="text-gray-500 mb-8 max-w-xs">No hay productos en tu carrito. Regresa a la tienda para elegir tus favoritos.</p>
        <Link to="/" className="bg-black text-white px-8 py-4 rounded-full font-black uppercase text-xs tracking-widest">VOLVER A LA TIENDA</Link>
      </div>
    );
  }

  if (step === 'success') {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-center p-6 animate-fade-in">
        <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-8 shadow-inner">
          <CheckCircle size={56} />
        </div>
        <h2 className="text-4xl md:text-6xl font-black uppercase mb-4 tracking-tighter italic">¡PEDIDO CONFIRMADO!</h2>
        <p className="text-gray-500 mb-10 max-w-md text-lg leading-relaxed">Gracias por tu compra. Te hemos enviado un email con los detalles de tu pedido y el seguimiento del envío.</p>
        <Link to="/" className="bg-black text-white px-12 py-5 rounded-full font-black uppercase text-sm tracking-widest shadow-xl hover:scale-105 transition-transform">
          VOLVER AL INICIO
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 md:px-12 py-16">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
        
        {/* Checkout Form */}
        <div className="lg:col-span-8 space-y-12">
          {/* Steps Indicator */}
          <div className="flex items-center gap-4">
            <div className={`flex items-center gap-2 text-sm font-black uppercase tracking-widest ${step === 'info' ? 'text-black' : 'text-gray-300'}`}>
              <span className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${step === 'info' ? 'border-black' : 'border-gray-200'}`}>1</span>
              DATOS
            </div>
            <div className="w-12 h-px bg-gray-200"></div>
            <div className={`flex items-center gap-2 text-sm font-black uppercase tracking-widest ${step === 'payment' ? 'text-black' : 'text-gray-300'}`}>
              <span className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${step === 'payment' ? 'border-black' : 'border-gray-200'}`}>2</span>
              PAGO
            </div>
          </div>

          {step === 'info' ? (
            <div className="space-y-8 animate-fade-in">
              <h2 className="text-3xl font-black uppercase italic tracking-tighter">DIRECCIÓN DE ENVÍO</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <input 
                  type="text" name="firstName" placeholder="Nombre" 
                  value={formData.firstName} onChange={handleInputChange}
                  className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black transition-all" 
                />
                <input 
                  type="text" name="lastName" placeholder="Apellidos" 
                  value={formData.lastName} onChange={handleInputChange}
                  className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black transition-all" 
                />
                <input 
                  type="email" name="email" placeholder="Email" 
                  value={formData.email} onChange={handleInputChange}
                  className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black transition-all md:col-span-2" 
                />
                <input 
                  type="text" name="address" placeholder="Dirección" 
                  value={formData.address} onChange={handleInputChange}
                  className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black transition-all md:col-span-2" 
                />
                <input 
                  type="text" name="city" placeholder="Ciudad" 
                  value={formData.city} onChange={handleInputChange}
                  className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black transition-all" 
                />
                <input 
                  type="text" name="zip" placeholder="Código Postal" 
                  value={formData.zip} onChange={handleInputChange}
                  className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black transition-all" 
                />
              </div>
              <button 
                onClick={nextStep}
                className="w-full md:w-auto px-12 py-5 bg-black text-white rounded-full font-black uppercase text-sm tracking-widest hover:bg-gray-900 shadow-xl"
              >
                CONTINUAR AL PAGO
              </button>
            </div>
          ) : (
            <div className="space-y-8 animate-fade-in">
              <div className="flex items-center justify-between">
                <h2 className="text-3xl font-black uppercase italic tracking-tighter">PAGO CON TARJETA</h2>
                <div className="flex gap-2">
                  <div className="bg-gray-100 px-3 py-1 rounded-md"><Lock size={16} /></div>
                  <div className="bg-gray-100 px-3 py-1 rounded-md text-[10px] font-black uppercase tracking-widest">SECURE</div>
                </div>
              </div>

              {/* Virtual Card Visualization */}
              <div className="bg-gradient-to-br from-gray-900 to-black p-8 rounded-3xl text-white shadow-2xl space-y-12 max-w-sm mx-auto md:mx-0">
                <div className="flex justify-between items-start">
                  <ShieldCheck size={32} className="text-red-600" />
                  <span className="font-black italic text-xl tracking-tighter">VISA</span>
                </div>
                <div className="space-y-4">
                  <p className="text-xl font-medium tracking-[0.3em] h-8">
                    {formData.cardNumber ? formData.cardNumber.replace(/(\d{4})/g, '$1 ').trim() : '•••• •••• •••• ••••'}
                  </p>
                  <div className="flex justify-between items-end">
                    <div>
                      <p className="text-[8px] font-bold text-gray-500 uppercase tracking-widest mb-1">TITULAR</p>
                      <p className="text-xs font-bold uppercase truncate max-w-[120px]">{formData.nameOnCard || 'TU NOMBRE'}</p>
                    </div>
                    <div>
                      <p className="text-[8px] font-bold text-gray-500 uppercase tracking-widest mb-1">EXP</p>
                      <p className="text-xs font-bold">{formData.expiry || 'MM/YY'}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <input 
                  type="text" name="nameOnCard" placeholder="Nombre en la tarjeta" 
                  value={formData.nameOnCard} onChange={handleInputChange}
                  className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black transition-all md:col-span-2" 
                />
                <input 
                  type="text" name="cardNumber" placeholder="Número de tarjeta" 
                  value={formData.cardNumber} onChange={handleInputChange} maxLength={16}
                  className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black transition-all md:col-span-2" 
                />
                <input 
                  type="text" name="expiry" placeholder="MM/YY" 
                  value={formData.expiry} onChange={handleInputChange} maxLength={5}
                  className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black transition-all" 
                />
                <input 
                  type="password" name="cvv" placeholder="CVV" 
                  value={formData.cvv} onChange={handleInputChange} maxLength={3}
                  className="w-full bg-gray-50 border-none rounded-xl p-5 text-sm font-medium focus:ring-2 focus:ring-black transition-all" 
                />
              </div>

              <div className="flex flex-col md:flex-row gap-4 pt-4">
                <button 
                  onClick={nextStep}
                  className="px-12 py-5 bg-black text-white rounded-full font-black uppercase text-sm tracking-widest flex items-center justify-center gap-3 shadow-xl hover:bg-gray-900"
                >
                  PAGAR ${total.toFixed(2)}
                </button>
                <button 
                  onClick={() => setStep('info')}
                  className="px-8 py-5 border-2 border-gray-100 rounded-full font-black uppercase text-xs tracking-widest text-gray-400 hover:text-black hover:border-black transition-all"
                >
                  VOLVER
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-4 bg-gray-50 rounded-3xl p-8 h-fit space-y-8 sticky top-32">
          <h3 className="text-xl font-black uppercase italic tracking-tighter">RESUMEN DEL PEDIDO</h3>
          
          <div className="space-y-6 max-h-80 overflow-y-auto pr-2 scrollbar-hide">
            {cart.map((item, idx) => (
              <div key={`${item.id}-${item.selectedSize}`} className="flex gap-4">
                <div className="w-16 h-16 bg-white rounded-xl overflow-hidden shrink-0 shadow-sm">
                  <img src={item.images[0]} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-grow">
                  <h4 className="text-xs font-bold uppercase truncate max-w-[150px]">{item.name}</h4>
                  <p className="text-[10px] text-gray-400 font-bold">Talla: {item.selectedSize} · Cant: {item.quantity}</p>
                </div>
                <span className="text-xs font-bold">${(item.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
          </div>

          <div className="space-y-4 pt-8 border-t border-gray-200">
            <div className="flex justify-between text-sm text-gray-500">
              <span>Subtotal</span>
              <span className="font-bold text-black">${total.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm text-gray-500">
              <span>Envío</span>
              <span className="font-bold text-green-600 uppercase tracking-widest text-[10px]">GRATIS</span>
            </div>
            <div className="flex justify-between text-xl font-black pt-4">
              <span>TOTAL</span>
              <span>${total.toFixed(2)}</span>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl flex items-center gap-4 border border-gray-100">
            <ShieldCheck className="text-gray-400" size={24} />
            <div className="text-[10px] font-bold text-gray-400 leading-tight uppercase tracking-widest">
              Transacción protegida <br />con SSL de 256 bits
            </div>
          </div>
        </div>

      </div>
      <style>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.4s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default CheckoutPage;
