
import { Product } from './types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Air Max Pro 2024',
    category: 'Sneakers',
    price: 129.99,
    description: 'La máxima comodidad se une al estilo urbano. Diseñadas para el día a día con una amortiguación excepcional.',
    images: [
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=600',
      'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&q=80&w=600'
    ],
    sizes: [38, 39, 40, 41, 42, 43, 44],
    colors: ['Rojo', 'Negro'],
    isNew: true
  },
  {
    id: '2',
    name: 'Desert Explorer Boots',
    category: 'Boots',
    price: 89.50,
    description: 'Botas resistentes para cualquier terreno. Cuero sintético de alta calidad y suela antideslizante.',
    images: [
      'https://images.unsplash.com/photo-1520639889413-5d55861b17d4?auto=format&fit=crop&q=80&w=600'
    ],
    sizes: [40, 41, 42, 43, 44, 45],
    colors: ['Marrón', 'Camel'],
    isOnSale: true
  },
  {
    id: '3',
    name: 'Classic Urban Loafers',
    category: 'Casual',
    price: 65.00,
    description: 'Elegancia casual para tus reuniones de fin de semana. Comodidad sin cordones.',
    images: [
      'https://images.unsplash.com/photo-1531310197839-ccf54634509e?auto=format&fit=crop&q=80&w=600'
    ],
    sizes: [39, 40, 41, 42, 43],
    colors: ['Negro', 'Azul Marino']
  }
];

export const INITIAL_CATEGORIES: { name: string; slug: string }[] = [
  { name: 'Todos', slug: 'all' },
  { name: 'Sneakers', slug: 'Sneakers' },
  { name: 'Botas', slug: 'Boots' },
  { name: 'Casual', slug: 'Casual' },
  { name: 'Formal', slug: 'Formal' },
  { name: 'Deportes', slug: 'Sports' }
];
