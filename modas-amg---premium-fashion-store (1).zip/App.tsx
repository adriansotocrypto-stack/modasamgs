
import React, { useState, useEffect, useMemo } from 'react';
import { HashRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Settings, Search, Menu, X, Instagram, Facebook, ArrowRight, ShoppingBag } from 'lucide-react';
import { Product, CartItem, Category } from './types';
import { INITIAL_PRODUCTS, INITIAL_CATEGORIES } from './constants';
import HomePage from './pages/HomePage';
import ProductDetailPage from './pages/ProductDetailPage';
import CheckoutPage from './pages/CheckoutPage';
import AdminPage from './pages/AdminPage';

export default function App() {
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('amg_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [categories, setCategories] = useState<{name: string, slug: string}[]>(() => {
    const saved = localStorage.getItem('amg_categories');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('amg_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('amg_categories', JSON.stringify(categories));
  }, [categories]);

  const addToCart = (product: Product, size: number) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id && item.selectedSize === size);
      if (existing) {
        return prev.map(item => 
          (item.id === product.id && item.selectedSize === size) 
            ? { ...item, quantity: item.quantity + 1 } 
            : item
        );
      }
      return [...prev, { ...product, selectedSize: size, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string, size: number) => {
    setCart(prev => prev.filter(item => !(item.id === productId && item.selectedSize === size)));
  };

  const updateQuantity = (productId: string, size: number, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === productId && item.selectedSize === size) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const cartTotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  }, [cart]);

  return (
    <HashRouter>
      <div className="min-h-screen flex flex-col">
        {/* Header */}
        <header className="sticky top-0 z-50 bg-white border-b border-gray-100 px-4 md:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsMenuOpen(true)}
              className="md:hidden text-gray-700 p-1 hover:bg-gray-100 rounded-md"
            >
              <Menu size={24} />
            </button>
            <Link to="/" className="text-2xl font-black tracking-tighter text-black uppercase">
              MODAS AMG
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-8 text-sm font-semibold uppercase tracking-wide">
            {categories.map(cat => (
              <Link 
                key={cat.slug} 
                to={`/?category=${cat.slug}`} 
                className="hover:text-red-600 transition-colors"
              >
                {cat.name}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            <Link to="/admin" className="text-gray-700 p-2 hover:bg-gray-50 rounded-full" title="Administración">
              <Settings size={20} />
            </Link>
            <button className="text-gray-700 p-2 hover:bg-gray-50 rounded-full">
              <Search size={20} />
            </button>
            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative text-gray-700 p-2 hover:bg-gray-50 rounded-full"
            >
              <ShoppingBag size={20} />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-black text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center">
                  {cart.reduce((s, i) => s + i.quantity, 0)}
                </span>
              )}
            </button>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage products={products} categories={categories} addToCart={addToCart} />} />
            <Route path="/product/:id" element={<ProductDetailPage products={products} addToCart={addToCart} />} />
            <Route path="/checkout" element={<CheckoutPage cart={cart} total={cartTotal} clearCart={() => setCart([])} />} />
            <Route path="/admin" element={<AdminPage products={products} setProducts={setProducts} categories={categories} setCategories={setCategories} />} />
          </Routes>
        </main>

        {/* Footer */}
        <footer className="bg-black text-white pt-16 pb-8 px-4 md:px-12 mt-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12 border-b border-gray-800 pb-12">
            <div className="space-y-4">
              <h2 className="text-2xl font-black uppercase tracking-tighter">MODAS AMG</h2>
              <p className="text-gray-400 text-sm leading-relaxed">
                Expertos en moda premium. Ofrecemos las últimas tendencias y la mejor calidad para tu estilo de vida.
              </p>
              <div className="flex gap-4">
                <Instagram className="cursor-pointer hover:text-gray-300" size={20} />
                <Facebook className="cursor-pointer hover:text-gray-300" size={20} />
              </div>
            </div>
            <div>
              <h3 className="font-bold uppercase mb-6 text-sm">Categorías</h3>
              <ul className="space-y-3 text-sm text-gray-400">
                {categories.slice(1).map(cat => (
                  <li key={cat.slug}><Link to={`/?category=${cat.slug}`} className="hover:text-white">{cat.name}</Link></li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="font-bold uppercase mb-6 text-sm">Soporte</h3>
              <ul className="space-y-3 text-sm text-gray-400">
                <li className="hover:text-white cursor-pointer">Seguir pedido</li>
                <li className="hover:text-white cursor-pointer">Envíos y devoluciones</li>
                <li className="hover:text-white cursor-pointer">Contacto</li>
                <li className="hover:text-white cursor-pointer"><Link to="/admin">Panel Admin</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold uppercase mb-6 text-sm">Newsletter</h3>
              <p className="text-xs text-gray-400 mb-4">Recibe ofertas exclusivas y lanzamientos.</p>
              <div className="flex bg-gray-900 rounded-lg p-1 overflow-hidden border border-gray-800">
                <input 
                  type="email" 
                  placeholder="Tu email..." 
                  className="bg-transparent border-none outline-none px-4 py-2 text-sm w-full"
                />
                <button className="bg-white text-black px-4 py-2 rounded-md font-bold text-xs">OK</button>
              </div>
            </div>
          </div>
          <p className="text-center text-xs text-gray-500">© 2024 MODAS AMG. Todos los derechos reservados.</p>
        </footer>

        {/* Cart Drawer */}
        {isCartOpen && (
          <div className="fixed inset-0 z-[100] bg-black bg-opacity-50 flex justify-end">
            <div className="w-full max-w-md bg-white h-full flex flex-col shadow-2xl animate-slide-in-right">
              <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                <h2 className="text-lg font-bold flex items-center gap-2">
                  <ShoppingBag size={20} /> TU CARRITO
                </h2>
                <button onClick={() => setIsCartOpen(false)} className="text-gray-400 hover:text-black">
                  <X size={24} />
                </button>
              </div>

              <div className="flex-grow overflow-y-auto p-6 space-y-6">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center opacity-60">
                    <ShoppingBag size={64} strokeWidth={1} className="mb-4" />
                    <p className="text-lg font-medium">Tu carrito está vacío</p>
                    <button onClick={() => setIsCartOpen(false)} className="mt-4 text-black font-bold underline underline-offset-4">
                      Empezar a comprar
                    </button>
                  </div>
                ) : (
                  cart.map((item, idx) => (
                    <div key={`${item.id}-${item.selectedSize}`} className="flex gap-4 group">
                      <div className="w-24 h-24 bg-gray-100 rounded-lg overflow-hidden shrink-0">
                        <img src={item.images[0]} alt={item.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-grow">
                        <div className="flex justify-between items-start">
                          <h3 className="font-bold text-sm uppercase">{item.name}</h3>
                          <button onClick={() => removeFromCart(item.id, item.selectedSize)} className="text-gray-400 hover:text-red-500">
                            <X size={16} />
                          </button>
                        </div>
                        <p className="text-xs text-gray-500 mt-1">Talla: {item.selectedSize}</p>
                        <div className="flex items-center justify-between mt-4">
                          <div className="flex items-center border rounded-md">
                            <button onClick={() => updateQuantity(item.id, item.selectedSize, -1)} className="px-2 py-1 hover:bg-gray-50 text-gray-500">-</button>
                            <span className="px-3 py-1 text-sm font-medium">{item.quantity}</span>
                            <button onClick={() => updateQuantity(item.id, item.selectedSize, 1)} className="px-2 py-1 hover:bg-gray-50 text-gray-500">+</button>
                          </div>
                          <span className="font-bold text-sm">${(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {cart.length > 0 && (
                <div className="p-6 border-t border-gray-100 bg-gray-50">
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-gray-500 font-medium">Subtotal</span>
                    <span className="text-xl font-black">${cartTotal.toFixed(2)}</span>
                  </div>
                  <Link to="/checkout" onClick={() => setIsCartOpen(false)} className="block w-full bg-black text-white text-center py-4 rounded-xl font-bold uppercase tracking-wider hover:bg-gray-900 transition-colors flex items-center justify-center gap-2">
                    FINALIZAR COMPRA <ArrowRight size={18} />
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="fixed inset-0 z-[100] bg-white flex flex-col p-6 animate-slide-in-left">
            <div className="flex items-center justify-between mb-12">
              <span className="text-2xl font-black tracking-tighter uppercase">MODAS AMG</span>
              <button onClick={() => setIsMenuOpen(false)}>
                <X size={32} />
              </button>
            </div>
            <nav className="flex flex-col gap-8 text-3xl font-black uppercase italic tracking-tighter">
              {categories.map(cat => (
                <Link 
                  key={cat.slug} 
                  to={`/?category=${cat.slug}`} 
                  onClick={() => setIsMenuOpen(false)}
                  className="hover:text-red-600 transition-colors flex items-center justify-between"
                >
                  {cat.name} <ArrowRight size={24} />
                </Link>
              ))}
            </nav>
            <div className="mt-auto pt-12 border-t flex gap-6">
              <Link to="/admin" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-2 font-bold uppercase text-xs tracking-widest"><Settings size={18}/> Admin</Link>
            </div>
          </div>
        )}
      </div>
      
      <style>{`
        @keyframes slide-in-right { from { transform: translateX(100%); } to { transform: translateX(0); } }
        @keyframes slide-in-left { from { transform: translateX(-100%); } to { transform: translateX(0); } }
        .animate-slide-in-right { animation: slide-in-right 0.3s cubic-bezier(0.16, 1, 0.3, 1); }
        .animate-slide-in-left { animation: slide-in-left 0.3s cubic-bezier(0.16, 1, 0.3, 1); }
      `}</style>
    </HashRouter>
  );
}
