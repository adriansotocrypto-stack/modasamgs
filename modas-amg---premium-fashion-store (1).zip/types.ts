
export type Category = 'Sneakers' | 'Boots' | 'Casual' | 'Formal' | 'Sports';

export interface Product {
  id: string;
  name: string;
  category: Category;
  price: number;
  description: string;
  images: string[];
  sizes: number[];
  colors: string[];
  isNew?: boolean;
  isOnSale?: boolean;
}

export interface CartItem extends Product {
  selectedSize: number;
  quantity: number;
}

export interface UserInfo {
  email: string;
  firstName: string;
  lastName: string;
  address: string;
  city: string;
  zipCode: string;
}

export interface PaymentInfo {
  cardNumber: string;
  expiryDate: string;
  cvv: string;
  cardHolder: string;
}
